package org.schabi.newpipe.extractor.linkhandler;

public final class ChannelTabs {
    public static final String VIDEOS = "videos";
    public static final String TRACKS = "tracks";
    public static final String SHORTS = "shorts";
    public static final String LIVESTREAMS = "livestreams";
    public static final String CHANNELS = "channels";
    public static final String PLAYLISTS = "playlists";
    public static final String PODCASTS = "podcasts";
    public static final String ALBUMS = "albums";
    public static final String SEARCH = "search";

    private ChannelTabs() {
    }
}
